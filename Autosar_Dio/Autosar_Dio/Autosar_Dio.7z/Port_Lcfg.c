/*
 * Port_Lcfg.c
 *
 * Created: 9/26/2022 3:55:38 PM
 *  Author: ibrahim.saber
 */ 

/* Include the Port interface file [SWS_Port_00205]*/
#include "Port.h"
/* Include Port_MemMap.h [SWS_Port_00205]*/
#include "Port_MemMap.h"
/* include Port_Cbk.h  */
#include "Port_Cbk.h"
