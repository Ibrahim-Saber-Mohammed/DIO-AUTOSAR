/*
 * Port_PBcfg.c
 *
 * Created: 9/26/2022 3:56:18 PM
 *  Author: ibrahim.saber
 */ 

/* Include Port.h [SWS_Port_00133] */
#include "Port.h"
/* Include Port_MemMap.h [SWS_Port_00133] */
#include "Port_MemMap.h"
