 /*********************************************************************/
 /****************** SWC : Compiler_Cfg.h    **************************/
 /****************** Version: V00            **************************/
 /****************** Date: Sep 21, 2022      **************************/
 /****************** Author: ibrahim.saber   **************************/
 /*********************************************************************/


#ifndef COMPILER_CFG_H_
#define COMPILER_CFG_H_

#define DIO_MEM_CLASS
#define DIO_PTR_CLASS
#define PORT_MEM_CLASS
#define PORT_PTR_CLASS

#endif /* COMPILER_CFG_H_ */
